﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Exam1_DianaCHuerta.Models;

[Table("employees")]
public partial class Employee
{
    [Key]
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public double Hours { get; set; }

    public double Salary { get; set; }

    public int Level { get; set; }
}
