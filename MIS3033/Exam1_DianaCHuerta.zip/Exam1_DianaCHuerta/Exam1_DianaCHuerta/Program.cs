﻿// MIS 3033 Exam 1 
// March 1,2024
//Diana C Huerta 
// 113553066

using Exam1_DianaCHuerta.Data;

Console.WriteLine("[Exam Code]"); // I will get exam code during the exam and replace it

Exam1DBCon db = new Exam1DBCon(); // database connection

var r = db.Employees.FirstOrDefault(); // first row, r is employee 
Console.WriteLine(r.Id);