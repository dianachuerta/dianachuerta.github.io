﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.Design;
using Microsoft.EntityFrameworkCore;

namespace Exam1_DianaCHuerta.Models;

[Table("employees")]
public partial class Employee
{
    [Key]
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public double Hours { get; set; } = 0;

    public double Salary { get; set; } = 0;

    public int Level { get; set; } = 0;

    public double CalculateSalary()
    {
        return Hours * 60;
    }

    public int CalculateSalaryLevel()
    {
        int level = 0;

        if(this.Salary<5000)
        {
            return level = 1;
        }
        else if (this.Salary<=10000)
        {
            return level = 2;
        }
        else
        {
            return level = 3;
        }
        return level;
       
    }

    public override string ToString()
    {
        return $"ID {this.Id}, Name: {this.Name}, {this.Salary:F2} (Level {this.Level})";
    }




}
