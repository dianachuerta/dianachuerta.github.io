﻿//  MIS 3033 001
// Feb 5, 2024
// Diana Huerta 
// 113553066

// step 1: 
using a;
using System.Text.Json;

Console.WriteLine("DB");
// step 2: <StartWorkingDirectory>$(MSBuildProjectDirectory)</StartWorkingDirectory>
// step 3: add 3 packages 
//Microsoft.EntityFrameworkCore.Design
//Microsoft.EntityFrameworkCore.Tools
//Microsoft.EntityFrameworkCore.Sqlite

// step 4: Design db table 
int age1;
double w1;

age1 = 20;
w1 = 128.8;// RAM, memory

// process: persist
File.WriteAllText("data.txt", $"{age1}\n{w1:f6}");//

Student stu1;// Student, complex
stu1 = new Student();

stu1.Id = "S113";
stu1.Name = "Tom";
stu1.Age = 19;
stu1.Grade = 96.6;
stu1.LetterGrade = 'A';

string stuStr;
var jsonOpts = new JsonSerializerOptions();//
jsonOpts.WriteIndented = true;
//JsonSerializerOptions jsonOpts= new JsonSerializerOptions();
stuStr = JsonSerializer.Serialize(stu1, jsonOpts);
File.WriteAllText("data.json", stuStr);

string dbStr;
//database
StuDB dB; // StuDB, complex, expensive 
dB= new StuDB();

//var r = dB.students.ToList();// IEmuneral ()
//var r = dB.students.Where(x => x.Age > 20 && x.Grade > 85).ToList();// IEmuneral ()

// table: collecetion: warehouse, list, array,dict 
// row: one single item in the table
// List<student>
// []: collection, table 
//{} : object 
//var r = dB.students.ToList();//table, collection, IEmuneral
// where (): result in a collection, table 


// judge bool student 
bool JudgeAge(Student a)
{// func body
    return a.Age>20 && a.Age<25;
}
// lamda expression, arrow function, function
//var r = dB.students.Where( b => b.Age> 20).ToList();
//var r = dB.students.Where(b => b.Age > 20).Where(b=>b.Age<25).Where(a=>a.Grade>85).ToList();
//var r = dB.students.Where(b => b.Age > 20 && b.Age<25 && b.Grade>200).ToList();

// Select () A table collection
//var r = dB.students.Where(b => b.Age > 20 && b.Age < 25).Select(x=> new {Grade=x.Grade,A=x.Age}).ToList();

// MaxBy: result in a row
var r = dB.students.Where(b => b.Age > 20 && b.Age < 25).ToList().MaxBy(b=>b.Grade);


dbStr = JsonSerializer.Serialize(r, jsonOpts);

Console.WriteLine(dbStr);
//Console.WriteLine(r.Count);
File.WriteAllText("data.json", dbStr);