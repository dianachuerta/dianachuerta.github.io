﻿//  MIS 3033 001
// Feb 5, 2024
// Diana Huerta 
// 113553066

// step 1: 
Console.WriteLine("DB");
// step 2: <StartWorkingDirectory>$(MSBuildProjectDirectory)</StartWorkingDirectory>
// step 3: add 3 packages 
//Microsoft.EntityFrameworkCore.Design
//Microsoft.EntityFrameworkCore.Tools
//Microsoft.EntityFrameworkCore.Sqlite

// step 4: Design db table 